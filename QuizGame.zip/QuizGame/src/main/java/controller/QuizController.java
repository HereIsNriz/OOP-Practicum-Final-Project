package controller;

import model.DatabaseManager;
import model.Player;
import model.Question;
import view.QuizView;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

public class QuizController {
    private QuizView view;
    private DatabaseManager dbManager;
    private Player currentPlayer;
    private List<Question> questions;
    private int currentQuestionIndex = 0;
    private boolean answered = false;
    
    private TimerThread timerThread; 

    public QuizController(QuizView view) {
        this.view = view;
        this.dbManager = new DatabaseManager();
        loadQuestions();
        initController();
    }

    private void loadQuestions() {
        questions = new ArrayList<>();
        questions.add(new Question("1. Apa ibu kota dari Jepang?", new String[]{"A. Seoul", "B. Tokyo", "C. Beijing"}, 1));
        questions.add(new Question("2. Sungai terpanjang di dunia adalah…", new String[]{"A. Sungai Amazon", "B. Sungai Nil", "C. Sungai Yangtze"}, 1));
        questions.add(new Question("3. Benua terbesar di dunia adalah…", new String[]{"A. Afrika", "B. Asia", "C. Eropa"}, 1));
        questions.add(new Question("4. Siapa penemu lampu pijar?", new String[]{"A. Thomas Alva Edison", "B. Albert Einstein", "C. Isaac Newton"}, 0));
        questions.add(new Question("5. Gunung tertinggi di dunia adalah…", new String[]{"A. Gunung Kilimanjaro", "B. Gunung Everest", "C. Gunung Fuji"}, 1));
        questions.add(new Question("6. Samudra terbesar di dunia adalah…", new String[]{"A. Samudra Atlantik", "B. Samudra Hindia", "C. Samudra Pasifik"}, 2));
        questions.add(new Question("7. Negara dengan populasi terbanyak di dunia adalah…", new String[]{"A. India", "B. Amerika Serikat", "C. Indonesia"}, 0));
        questions.add(new Question("8. Apa mata uang resmi dari Amerika Serikat?", new String[]{"A. Euro", "B. Dolar", "C. Yen"}, 1));
        questions.add(new Question("9. Planet terbesar di tata surya adalah…", new String[]{"A. Bumi", "B. Saturnus", "C. Jupiter"}, 2));
        questions.add(new Question("10. Siapa presiden pertama Indonesia?", new String[]{"A. Soekarno", "B. Soeharto", "C. B. J. Habibie"}, 0));
    }

    private void initController() {
        view.startButton.addActionListener(e -> startGame());
        view.submitButton.addActionListener(e -> submitAnswer());
        view.leaderboardButton.addActionListener(e -> showLeaderboard());
        view.exitButton.addActionListener(e -> System.exit(0));
    }

    private void startGame() {
        String username = view.usernameField.getText().trim();
        if (username.isEmpty()) {
            JOptionPane.showMessageDialog(view, "Username tidak boleh kosong!");
            return;
        }
        currentPlayer = new Player(username);
        currentQuestionIndex = 0;
        view.showPanel("QUIZ");
        displayQuestion();
    }

    private void displayQuestion() {
        answered = false;
        view.optionsGroup.clearSelection();
        if (currentQuestionIndex < questions.size()) {
            Question q = questions.get(currentQuestionIndex);
            view.questionLabel.setText(q.getText());
            view.optA.setText(q.getOptions()[0]);
            view.optB.setText(q.getOptions()[1]);
            view.optC.setText(q.getOptions()[2]);
            
            startTimer();
        } else {
            endGame();
        }
    }

    private void submitAnswer() {
        if (answered) return;
        answered = true;
        stopTimer();
        checkAnswer();
        currentQuestionIndex++;
        displayQuestion();
    }

    private void checkAnswer() {
        int selectedIndex = -1;
        if (view.optA.isSelected()) selectedIndex = 0;
        else if (view.optB.isSelected()) selectedIndex = 1;
        else if (view.optC.isSelected()) selectedIndex = 2;
        
        if (selectedIndex == -1) {
            JOptionPane.showMessageDialog(view, "Pilih jawaban dulu!");
            return;
        }

        if (selectedIndex != -1 && questions.get(currentQuestionIndex).isCorrect(selectedIndex)) {
            currentPlayer.addCorrectAnswer();
        } else {
            currentPlayer.addWrongAnswer();
        }
    }

    private void startTimer() {
        stopTimer();
        timerThread = new TimerThread(this, 10);
        timerThread.start();
    }

    private void stopTimer() {
        if (timerThread != null && timerThread.isAlive()) {
            timerThread.interrupt();
        }
    }

    public void timeUp() {
        stopTimer();
        SwingUtilities.invokeLater(() -> {
            currentPlayer.addWrongAnswer();
            currentQuestionIndex++;
            displayQuestion();
        });
    }

    public void updateTimerUI(int secondsLeft) {
        SwingUtilities.invokeLater(() -> view.timerLabel.setText("Waktu: " + secondsLeft));
    }

    private void endGame() {
        dbManager.saveScore(currentPlayer);
        view.resultScoreLabel.setText("Nilai Akhir: " + currentPlayer.getScore());
        view.resultDetailLabel.setText("Benar: " + currentPlayer.getCorrectAnswers() + " | Salah: " + currentPlayer.getWrongAnswers());
        view.showPanel("RESULT");
    }

    private void showLeaderboard() {
        List<Player> topPlayers = dbManager.getLeaderboard();
        StringBuilder sb = new StringBuilder();
        int rank = 1;
        for (Player p : topPlayers) {
            sb.append(rank).append(". ").append(p.getUsername()).append("\tScore: ").append(p.getScore()).append("\n");
            rank++;
        }
        view.leaderboardArea.setText(sb.toString());
        view.showPanel("LEADERBOARD");
    }
}
package view;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class QuizView extends JFrame {
    CardLayout cardLayout = new CardLayout();
    JPanel mainPanel = new JPanel(cardLayout);

    JPanel loginPanel = new JPanel(new GridLayout(3, 1, 10, 10));
    public JTextField usernameField = new JTextField();
    public JButton startButton = new JButton("Mulai Quiz");

    JPanel quizPanel = new JPanel(new BorderLayout());
    public JLabel questionLabel = new JLabel("Pertanyaan", SwingConstants.CENTER);
    public JLabel timerLabel = new JLabel("Waktu: 10", SwingConstants.CENTER);
    public JRadioButton optA = new JRadioButton("A");
    public JRadioButton optB = new JRadioButton("B");
    public JRadioButton optC = new JRadioButton("C");
    public ButtonGroup optionsGroup = new ButtonGroup();
    public JButton submitButton = new JButton("Submit / Lanjut");

    JPanel resultPanel = new JPanel(new GridLayout(5, 1, 10, 10));
    public JLabel resultScoreLabel = new JLabel("", SwingConstants.CENTER);
    public JLabel resultDetailLabel = new JLabel("", SwingConstants.CENTER);
    public JButton leaderboardButton = new JButton("Lihat Leaderboard");

    JPanel leaderboardPanel = new JPanel(new BorderLayout());
    public JTextArea leaderboardArea = new JTextArea();
    public JButton exitButton = new JButton("Keluar");

    public QuizView() {
        setTitle("Game Quiz Pengetahuan Umum");
        setSize(500, 350);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        setupLoginPanel();
        setupQuizPanel();
        setupResultPanel();
        setupLeaderboardPanel();

        add(mainPanel);
    }

    private void setupLoginPanel() {
        loginPanel.setBorder(BorderFactory.createEmptyBorder(50, 50, 50, 50));
        loginPanel.add(new JLabel("Masukkan Username Anda:", SwingConstants.CENTER));
        loginPanel.add(usernameField);
        loginPanel.add(startButton);
        mainPanel.add(loginPanel, "LOGIN");
    }

    private void setupQuizPanel() {
        quizPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        questionLabel.setFont(new Font("Arial", Font.BOLD, 14));
        timerLabel.setFont(new Font("Arial", Font.BOLD, 16));
        timerLabel.setForeground(Color.RED);

        optionsGroup.add(optA);
        optionsGroup.add(optB);
        optionsGroup.add(optC);

        JPanel optionsPanel = new JPanel(new GridLayout(3, 1));
        optionsPanel.add(optA);
        optionsPanel.add(optB);
        optionsPanel.add(optC);

        JPanel centerPanel = new JPanel(new BorderLayout(0, 20));
        centerPanel.add(questionLabel, BorderLayout.NORTH);
        centerPanel.add(optionsPanel, BorderLayout.CENTER);

        quizPanel.add(timerLabel, BorderLayout.NORTH);
        quizPanel.add(centerPanel, BorderLayout.CENTER);
        
        JPanel bottomPanel = new JPanel();
        bottomPanel.add(submitButton);
        quizPanel.add(bottomPanel, BorderLayout.SOUTH);
        mainPanel.add(quizPanel, "QUIZ");
    }

    private void setupResultPanel() {
        resultPanel.setBorder(BorderFactory.createEmptyBorder(50, 50, 50, 50));
        resultScoreLabel.setFont(new Font("Arial", Font.BOLD, 18));
        resultPanel.add(new JLabel("Quiz Selesai!", SwingConstants.CENTER));
        resultPanel.add(resultScoreLabel);
        resultPanel.add(resultDetailLabel);
        resultPanel.add(leaderboardButton);
        mainPanel.add(resultPanel, "RESULT");
    }

    private void setupLeaderboardPanel() {
        leaderboardArea.setEditable(false);
        leaderboardArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
        leaderboardPanel.add(new JLabel("=== LEADERBOARD ===", SwingConstants.CENTER), BorderLayout.NORTH);
        leaderboardPanel.add(new JScrollPane(leaderboardArea), BorderLayout.CENTER);
        leaderboardPanel.add(exitButton, BorderLayout.SOUTH);
        mainPanel.add(leaderboardPanel, "LEADERBOARD");
    }

    public void showPanel(String panelName) {
        cardLayout.show(mainPanel, panelName);
    }
}
package model;

public class Player extends User {
    private int score;
    private int correctAnswers;
    private int wrongAnswers;

    public Player(String username) {
        super(username);
        this.score = 0;
        this.correctAnswers = 0;
        this.wrongAnswers = 0;
    }

    public Player(String username, int score) {
        super(username);
        this.score = score;
        this.correctAnswers = 0;
        this.wrongAnswers = 0;
    }

    public void addCorrectAnswer() {
        this.correctAnswers++;
        this.score += 10;
    }

    public void addWrongAnswer() {
        this.wrongAnswers++;
    }

    public int getScore() { return score; }
    public int getCorrectAnswers() { return correctAnswers; }
    public int getWrongAnswers() { return wrongAnswers; }

    @Override
    public String toString() {
        return username + " - Score: " + score;
    }
}
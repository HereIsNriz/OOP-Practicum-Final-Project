package controller;

public class TimerThread extends Thread {
    private QuizController quizController;
    private int timeLeft;

    public TimerThread(QuizController quizController, int seconds){
        this.quizController = quizController;
        this.timeLeft = seconds;
    }

    @Override
    public void run() {
        try {
            while (timeLeft > 0) {
                quizController.updateTimerUI(timeLeft);
                Thread.sleep(1000);
                timeLeft--;
            }
            quizController.updateTimerUI(0);
            quizController.timeUp();
        } catch (InterruptedException e){
        }
    }
}
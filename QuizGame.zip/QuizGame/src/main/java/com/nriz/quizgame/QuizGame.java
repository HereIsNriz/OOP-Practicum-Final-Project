package com.nriz.quizgame;

import javax.swing.*;
import view.*;
import controller.*;

public class QuizGame {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            QuizView view = new QuizView();
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                e.printStackTrace();
            }
            new QuizController(view);
            view.setVisible(true);
        });
    }
}